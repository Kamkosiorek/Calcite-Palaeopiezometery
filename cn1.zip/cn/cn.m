Kamil you will get 70+ for the thesis
